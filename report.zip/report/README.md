# 浙江大学实验报告模板

[![CircleCI](https://circleci.com/gh/megrxu/zju-report-latex-template.svg?style=svg)](https://circleci.com/gh/megrxu/zju-report-latex-template)

A LaTeX template of report in required format.

## Usage

Simply

```bash
xelatex report.tex
```
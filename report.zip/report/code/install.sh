sudo apt install mininet
sudo apt install build-essential xterm wireshark ethtool iperf traceroute iptables arptables
